import type { Timestamp } from "firebase/firestore";

export interface User {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  createdAt: Timestamp;
}

export interface ContentItem {
  id: string;
  title: string;
  description: string;
  fileUrl: string;
  fileType: string;
  category: string;
  thumbnailUrl?: string;
  size: number;
  userId: string;
  userName: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
  likes: number;
  downloads: number;
  comments?: Comment[];
}

export interface Comment {
  id: string;
  text: string;
  userId: string;
  userName: string;
  userPhotoURL?: string;
  createdAt: Timestamp;
}

export type FileCategory = 'video' | 'photo' | 'application' | 'document' | 'audio' | 'other';

export interface FileUpload {
  file: File;
  progress: number;
  error: string | null;
  category: FileCategory;
  title: string;
  description: string;
}
