import Link from "next/link";
import { Button } from "@/components/ui/button";
import type { FileCategory } from "@/types";

// Mock categories with icons
const categories: { name: string; icon: string; slug: FileCategory }[] = [
  { name: "Videos", icon: "🎬", slug: "video" },
  { name: "Photos", icon: "📷", slug: "photo" },
  { name: "Applications", icon: "📱", slug: "application" },
  { name: "Documents", icon: "📄", slug: "document" },
  { name: "Audio", icon: "🎵", slug: "audio" },
  { name: "Other", icon: "📦", slug: "other" },
];

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <section className="mb-12">
        <div className="bg-gradient-to-r from-primary to-primary/70 text-primary-foreground rounded-lg p-8 md:p-12 flex flex-col md:flex-row items-center justify-between">
          <div className="mb-6 md:mb-0 md:mr-6">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              Welcome to Abhishek Adhurjya&apos;s Content Platform
            </h1>
            <p className="text-lg md:text-xl mb-6 max-w-2xl">
              Share and discover videos, photos, applications, and more. Upload your content and let others explore what you&apos;ve created.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button size="lg" asChild>
                <Link href="/upload">Upload Content</Link>
              </Button>
              <Button size="lg" variant="secondary" asChild>
                <Link href="/sign-up">Sign Up</Link>
              </Button>
            </div>
          </div>
          <div className="flex-shrink-0">
            <div className="w-full md:w-80 h-60 bg-primary-foreground/10 flex items-center justify-center rounded-lg">
              <div className="text-6xl">📁</div>
            </div>
          </div>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Browse by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => (
            <Link
              key={category.name}
              href={`/category/${category.slug}`}
              className="flex flex-col items-center justify-center bg-card hover:bg-accent transition-colors p-6 rounded-lg border"
            >
              <span className="text-4xl mb-3">{category.icon}</span>
              <span className="text-lg font-medium">{category.name}</span>
            </Link>
          ))}
        </div>
      </section>

      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Recently Added</h2>
          <Button variant="link" asChild>
            <Link href="/explore">View all</Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="border rounded-lg overflow-hidden bg-card">
              <div className="aspect-video bg-muted animate-pulse" />
              <div className="p-4">
                <div className="h-6 bg-muted rounded animate-pulse mb-2" />
                <div className="h-4 bg-muted rounded animate-pulse w-3/4 mb-3" />
                <div className="flex justify-between">
                  <div className="h-8 bg-muted rounded animate-pulse w-1/3" />
                  <div className="h-8 bg-muted rounded animate-pulse w-1/3" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Popular</h2>
          <Button variant="link" asChild>
            <Link href="/popular">View all</Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="border rounded-lg overflow-hidden bg-card">
              <div className="aspect-video bg-muted animate-pulse" />
              <div className="p-4">
                <div className="h-6 bg-muted rounded animate-pulse mb-2" />
                <div className="h-4 bg-muted rounded animate-pulse w-3/4 mb-3" />
                <div className="flex justify-between">
                  <div className="h-8 bg-muted rounded animate-pulse w-1/3" />
                  <div className="h-8 bg-muted rounded animate-pulse w-1/3" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
