"use client";

import React, { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { uploadFile, getFileType } from "@/lib/uploadFile";
import type { FileUpload, FileCategory } from "@/types";
import { toast } from "sonner";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { UploadCloud, FileText, X } from "lucide-react";

export default function UploadPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [files, setFiles] = useState<FileUpload[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  // Redirect if not logged in
  React.useEffect(() => {
    if (!loading && !user) {
      toast.error("You need to be signed in to upload files");
      router.push("/sign-in");
    }
  }, [user, loading, router]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles = acceptedFiles.map((file) => ({
      file,
      progress: 0,
      error: null,
      category: getFileType(file) as FileCategory,
      title: file.name.split(".")[0],
      description: "",
    }));
    setFiles((prev) => [...prev, ...newFiles]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: true,
  });

  const handleRemoveFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleUpdateFileField = (
    index: number,
    field: keyof FileUpload,
    value: string
  ) => {
    setFiles((prev) =>
      prev.map((file, i) =>
        i === index ? { ...file, [field]: value } : file
      )
    );
  };

  const handleUpload = async () => {
    if (!user) {
      toast.error("You need to be signed in to upload files");
      return;
    }

    // Validate files
    const invalidFiles = files.filter((file) => !file.title.trim());
    if (invalidFiles.length > 0) {
      toast.error("All files must have a title");
      return;
    }

    setIsUploading(true);

    try {
      // Upload each file
      const uploadPromises = files.map((fileUpload, index) => {
        return new Promise<void>((resolve, reject) => {
          uploadFile({
            file: fileUpload.file,
            title: fileUpload.title,
            description: fileUpload.description,
            category: fileUpload.category,
            userId: user.uid,
            userName: user.displayName || "Unknown User",
            onProgress: (progress) => {
              setFiles((prev) =>
                prev.map((f, i) =>
                  i === index ? { ...f, progress } : f
                )
              );
            },
            onError: (error) => {
              setFiles((prev) =>
                prev.map((f, i) =>
                  i === index ? { ...f, error: error.message } : f
                )
              );
              reject(error);
            },
            onSuccess: () => {
              resolve();
            },
          });
        });
      });

      await Promise.all(uploadPromises);
      toast.success("All files uploaded successfully");
      setFiles([]);
      router.push("/profile");
    } catch (error) {
      toast.error("Some files failed to upload");
      console.error("Upload error:", error);
    } finally {
      setIsUploading(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle className="h-8 bg-muted animate-pulse rounded" />
            <CardDescription className="h-4 bg-muted animate-pulse rounded w-3/4" />
          </CardHeader>
          <CardContent className="h-40 bg-muted animate-pulse rounded" />
          <CardFooter className="h-10 bg-muted animate-pulse rounded" />
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Card>
        <CardHeader>
          <CardTitle>Upload Content</CardTitle>
          <CardDescription>
            Share your videos, photos, applications and more with everyone.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
              isDragActive
                ? "border-primary bg-primary/10"
                : "border-muted-foreground/20 hover:border-muted-foreground/50"
            }`}
          >
            <input {...getInputProps()} />
            <UploadCloud className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-lg font-medium">
              {isDragActive
                ? "Drop the files here..."
                : "Drag 'n' drop some files here, or click to select files"}
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Upload any type of files you want to share
            </p>
          </div>

          {files.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Files to Upload</h3>
              {files.map((file, index) => (
                <div key={`file-${index}`} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center">
                      <FileText className="h-6 w-6 mr-2 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{file.file.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(file.file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRemoveFile(index)}
                      disabled={isUploading}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="space-y-3">
                    <div className="grid gap-2">
                      <Label htmlFor={`title-${index}`}>Title</Label>
                      <Input
                        id={`title-${index}`}
                        value={file.title}
                        onChange={(e) =>
                          handleUpdateFileField(index, "title", e.target.value)
                        }
                        disabled={isUploading}
                        placeholder="Enter a title for your file"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor={`description-${index}`}>
                        Description
                      </Label>
                      <Textarea
                        id={`description-${index}`}
                        value={file.description}
                        onChange={(e) =>
                          handleUpdateFileField(
                            index,
                            "description",
                            e.target.value
                          )
                        }
                        disabled={isUploading}
                        placeholder="Add a description (optional)"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor={`category-${index}`}>Category</Label>
                      <Select
                        value={file.category}
                        onValueChange={(value) =>
                          handleUpdateFileField(
                            index,
                            "category",
                            value as FileCategory
                          )
                        }
                        disabled={isUploading}
                      >
                        <SelectTrigger id={`category-${index}`}>
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="video">Video</SelectItem>
                          <SelectItem value="photo">Photo</SelectItem>
                          <SelectItem value="application">Application</SelectItem>
                          <SelectItem value="document">Document</SelectItem>
                          <SelectItem value="audio">Audio</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {file.progress > 0 && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Uploading...</span>
                          <span>{Math.round(file.progress)}%</span>
                        </div>
                        <Progress value={file.progress} />
                      </div>
                    )}

                    {file.error && (
                      <div className="bg-destructive/10 text-destructive p-2 rounded text-sm">
                        {file.error}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button
            variant="outline"
            onClick={() => setFiles([])}
            disabled={files.length === 0 || isUploading}
          >
            Clear All
          </Button>
          <Button
            onClick={handleUpload}
            disabled={files.length === 0 || isUploading}
          >
            {isUploading ? "Uploading..." : "Upload Files"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
