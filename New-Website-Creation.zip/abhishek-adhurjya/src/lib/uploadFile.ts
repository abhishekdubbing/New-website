import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { storage, db } from "./firebase";
import { doc, setDoc, serverTimestamp, collection } from "firebase/firestore";
import type { FileCategory, ContentItem } from "@/types";
import { v4 as uuidv4 } from "uuid";

export const getFileType = (file: File): FileCategory => {
  const type = file.type.split("/")[0];

  if (type === "video") return "video";
  if (type === "image") return "photo";
  if (type === "audio") return "audio";

  // Check for common application extensions
  const extension = file.name.split(".").pop()?.toLowerCase();
  if (extension) {
    if (["exe", "apk", "dmg", "app", "msi", "deb", "rpm"].includes(extension)) {
      return "application";
    }
    if (["doc", "docx", "pdf", "txt", "xls", "xlsx", "ppt", "pptx"].includes(extension)) {
      return "document";
    }
  }

  return "other";
};

interface UploadFileParams {
  file: File;
  title: string;
  description: string;
  category: FileCategory;
  userId: string;
  userName: string;
  onProgress?: (progress: number) => void;
  onError?: (error: Error) => void;
  onSuccess?: (downloadUrl: string, fileData: ContentItem) => void;
}

export const uploadFile = ({
  file,
  title,
  description,
  category,
  userId,
  userName,
  onProgress,
  onError,
  onSuccess,
}: UploadFileParams): () => void => {
  // Create a unique file ID
  const fileId = uuidv4();

  // Create a reference to the file in Firebase Storage
  const storageRef = ref(storage, `uploads/${userId}/${fileId}-${file.name}`);

  // Create the upload task
  const uploadTask = uploadBytesResumable(storageRef, file);

  // Set up task listeners
  uploadTask.on(
    "state_changed",
    (snapshot) => {
      // Track upload progress
      const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
      if (onProgress) {
        onProgress(progress);
      }
    },
    (error) => {
      // Handle errors
      if (onError) {
        onError(error);
      }
    },
    async () => {
      // Upload completed successfully
      try {
        // Get the download URL
        const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);

        // Create file metadata document in Firestore
        const fileData: ContentItem = {
          id: fileId,
          title,
          description,
          fileUrl: downloadUrl,
          fileType: file.type,
          category,
          size: file.size,
          userId,
          userName,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          likes: 0,
          downloads: 0,
        };

        // Add thumbnail URL for images
        if (category === "photo") {
          fileData.thumbnailUrl = downloadUrl;
        }

        // Save to Firestore
        await setDoc(doc(db, "content", fileId), fileData);

        // Call success callback
        if (onSuccess) {
          onSuccess(downloadUrl, fileData);
        }
      } catch (error) {
        if (onError && error instanceof Error) {
          onError(error);
        }
      }
    }
  );

  // Return a function to cancel the upload if needed
  return () => uploadTask.cancel();
};
