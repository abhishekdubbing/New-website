"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import {
  Download,
  Heart,
  MessageSquare,
  Video,
  FileText,
  Music,
  Package,
  Smartphone,
  Calendar,
  Share2
} from "lucide-react";
import type { ContentItem } from "@/types";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";

interface ContentCardProps {
  item: ContentItem;
  onLike?: (id: string) => void;
  onDownload?: (id: string) => void;
}

const ContentCard = ({ item, onLike, onDownload }: ContentCardProps) => {
  const getThumbnail = () => {
    if (item.thumbnailUrl) {
      return (
        <div className="relative aspect-video w-full overflow-hidden rounded-t-lg">
          <Image
            src={item.thumbnailUrl}
            alt={item.title}
            fill
            className="object-cover transition-transform hover:scale-105"
          />
        </div>
      );
    }

    // Default placeholder based on content type
    const getCategoryIcon = () => {
      switch (item.category) {
        case "video":
          return <Video size={48} />;
        case "audio":
          return <Music size={48} />;
        case "application":
          return <Smartphone size={48} />;
        case "document":
          return <FileText size={48} />;
        default:
          return <Package size={48} />;
      }
    };

    return (
      <div className="flex aspect-video w-full items-center justify-center rounded-t-lg bg-muted">
        {getCategoryIcon()}
      </div>
    );
  };

  const formatFileSize = (bytes: number) => {
    const mb = bytes / (1024 * 1024);
    if (mb < 1) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${mb.toFixed(1)} MB`;
  };

  const getTimeAgo = () => {
    if (item.createdAt && 'seconds' in item.createdAt) {
      const date = new Date(item.createdAt.seconds * 1000);
      return formatDistanceToNow(date, { addSuffix: true });
    }
    return "Recently";
  };

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <Link href={`/content/${item.id}`}>
        {getThumbnail()}
      </Link>
      <CardContent className="p-4">
        <div className="mb-2 flex items-start justify-between">
          <Link href={`/content/${item.id}`} className="line-clamp-2 font-medium hover:underline">
            {item.title}
          </Link>
          <Badge variant="outline" className="text-xs capitalize">
            {item.category}
          </Badge>
        </div>
        <p className="line-clamp-2 text-sm text-muted-foreground mb-2">
          {item.description || "No description provided"}
        </p>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>By {item.userName}</span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            {getTimeAgo()}
          </span>
          <span>•</span>
          <span>{formatFileSize(item.size)}</span>
        </div>
      </CardContent>
      <CardFooter className="p-2 flex justify-between border-t">
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={onLike ? () => onLike(item.id) : undefined}
            className="h-8 w-8"
          >
            <Heart className="h-4 w-4" />
          </Button>
          <span className="text-xs">{item.likes}</span>
          <Link href={`/content/${item.id}#comments`}>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MessageSquare className="h-4 w-4" />
            </Button>
          </Link>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Share2 className="h-4 w-4" />
          </Button>
        </div>
        <Button
          size="sm"
          onClick={onDownload ? () => onDownload(item.id) : undefined}
          className="h-8"
        >
          <Download className="h-4 w-4 mr-1" />
          Download
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ContentCard;
